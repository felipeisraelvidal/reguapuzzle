from enum import Enum

class GameState(Enum):
    SUCCESS = 0
    FAIL    = 1
    PLAYING = 2